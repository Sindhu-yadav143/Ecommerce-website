from django.shortcuts import render,redirect
from .models import User, Product ,Order , Cart

def login(req):
    if req.method == 'POST':
        mail = req.POST.get("mail")
        pswd = req.POST.get("pswd")
        user = User.objects.get(email=mail)
        if user is not None:
            if user.password == pswd:
                res = redirect("home")
                res.set_cookie("user_id", user.id)
                return res
            else:
                error ='Invalid password'
        else:
            error ='Invalid mail'
    return render(req,"login.html",locals())

def home(req):
    user_id = req.COOKIES.get("user_id")
    if user_id is None:
        return redirect("login")
    user = User.objects.get(id=user_id)
    data = Product.objects.all()
    return render(req, "index.html",locals())

def nature(req,ele):
    user_id = req.COOKIES.get("user_id")
    if user_id is None:
        return redirect("login")
    user = User.objects.get(id=user_id)
    data = Product.objects.filter(product_type=ele)
    return render(req, "index.html",locals())

def search(req):
    user_id = req.COOKIES.get("user_id")
    if user_id is None:
        return redirect("login")
    user = User.objects.get(id=user_id)
    if req.method == 'GET':
        search = req.GET.get("search")
        data = Product.objects.filter(product_name__contains=search)
    return render(req, "index.html",locals())

def logout(req):
    res = redirect("login")
    res.delete_cookie('user_id')
    return res

def account(req):
    user_id = req.COOKIES.get("user_id")
    if user_id is None:
        return redirect("login")
    user = User.objects.get(id=user_id)
    return render(req, "account.html",locals())

def upadate_account(req):
    user_id = req.COOKIES.get("user_id")
    if user_id is None:
        return redirect("login")
    user = User.objects.get(id=user_id)
    if req.method == 'POST':
        user.username = req.POST.get("name")
        user.contact = req.POST.get("phno")
        user.address = req.POST.get("add")
        if req.FILES:
            user.image = req.FILES.get("avatar")
        user.save()
        return redirect("account")
    return render(req, "update_account.html",locals())

def place_order(req,ele):
    user_id = req.COOKIES.get("user_id")
    if user_id is None:
        return redirect("login")
    user = User.objects.get(id=user_id)
    product = Product.objects.get(id=ele)
    if req.method == 'POST':
        address = req.POST.get("name")+ " "+ req.POST.get("phone")+" "+ req.POST.get("street")+" "+ req.POST.get("state")+" "+ req.POST.get("pin")
        new = Order(name = product.product_name , address = address , user_id=user_id , product_id=product.id)
        new.save()
    return render(req, "place_order.html",locals())

def view_order(req):
    user_id = req.COOKIES.get("user_id")
    if user_id is None:
        return redirect("login")
    data = [Product.objects.get(id=j) for j in [i.product_id for i in Order.objects.filter(user_id=user_id)]]
    return render(req, "view_order.html",locals())

def add_kart(req,ele):
    user_id = req.COOKIES.get("user_id")
    if user_id is None:
        return redirect("login")
    new = Cart(user_id=user_id , product_id=ele)
    new.save()
    return redirect("home")
    
def kart(req):
    user_id = req.COOKIES.get("user_id")
    if user_id is None:
        return redirect("login")
    data = [Product.objects.get(id=j) for j in [i.product_id for i in Cart.objects.filter(user_id=user_id)]]
    return render(req, "cart.html",locals())
def signup(req):
    if req.method == 'POST':
        contact = req.POST.get("contact")
        name = req.POST.get("name")
        mail = req.POST.get("mail")
        pswd1 = req.POST.get("pswd1")
        pswd2 = req.POST.get("pswd2")
        if not (User.objects.filter(email=mail).first()):
            if pswd1 == pswd2:
                user = User(username=name, contact=contact, email=mail, password=pswd1)
                user.save()
                msg = "account created successfully please login !!"
            else:
                error = "password and re-enter password do not match"
        else:
            error = "this e-mail already have account !!"
        
    return render(req,"signup.html",locals())