const demo =()=>{
    document.getElementById("pic").src=URL.createObjectURL(document.getElementById("imag").files[0])
}