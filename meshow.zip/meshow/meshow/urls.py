from django.contrib import admin
from django.urls import path
from webapp.views import *
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    path ('', login, name='login'),
    path ('signup/', signup, name='signup'),
    path ('user/logout', logout, name='logout'),
    path ('user/home', home, name='home'),
    path ('user/search/', search, name='search'),
    path ('user/account/', account, name='account'),
    path ('user/view/order/', view_order, name='view_order'),
    path ('user/account/upadate/', upadate_account, name='update_account'),
    path ('user/type/<str:ele>', nature, name='nature'),
    path ('user/Kart/<str:ele>', add_kart, name='add_kart'),
    path ('user/view/Kart/', kart, name='kart'),
    path ('user/place/order/<int:ele>',place_order, name='place_order'),
]


urlpatterns += static(settings.STATIC_URL , document_root = settings.STATIC_ROOT)
urlpatterns += static(settings.MEDIA_URL , document_root = settings.MEDIA_ROOT)