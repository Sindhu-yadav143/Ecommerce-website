from django.db import models

class User(models.Model):
    username = models.CharField(max_length=255)
    email    = models.EmailField(unique=True)
    password = models.CharField(max_length=16)
    image    = models.ImageField(upload_to='user/')
    contact  = models.CharField(max_length= 16)
    address  = models.TextField(max_length=255,null=True)
    def __str__(self):
        return self.username
        

type_list = [
    ('men', 'Men'),
    ('women', 'Women'),
    ('kids', 'Kids'),
    ('toys', 'Toys'),
    ('healthcare', 'Helth Care'),
    ('beauty', 'Beauty'),
]

class Product(models.Model):
    product_name = models.CharField(max_length=255)
    product_price = models.DecimalField(max_digits=10, decimal_places=2)
    product_discount = models.DecimalField(max_digits=10, decimal_places=2)
    product_image = models.ImageField(upload_to='product/')
    product_type = models.CharField(choices=type_list,max_length=10)
    product_description = models.TextField(max_length=255)

    def __str__(self):
        return self.product_name

class Order(models.Model):
    user_id =models.IntegerField()
    product_id = models.IntegerField()
    name = models.CharField(max_length=50)
    address = models.TextField()
    def __str__(self):
        return self.name
    
class Cart(models.Model):
    user_id = models.IntegerField()
    product_id = models.IntegerField()
    def __str__(self):
        return str(self.user_id) + " " + str(self.product_id)


